from flask import Flask, request, jsonify
from ai_helper import get_ai_response
from dotenv import load_dotenv

load_dotenv()
app = Flask(__name__)

@app.route("/ask", methods=["POST"])
def ask():
    data = request.json
    question = data.get("question")
    answer = get_ai_response(question)
    return jsonify({"response": answer})

if __name__ == "__main__":
    app.run(debug=True)
