# 🤖 AI Coding Helper

AI Coding Helper is an intelligent assistant that helps users with coding only, across all programming languages.

## Features
- Explain code in simple language
- Debug errors
- Improve and optimize code
- Supports all programming languages

## Tech Stack
- Backend: Python, Flask
- Frontend: HTML, CSS, JavaScript

## How to Run
1. Install requirements
2. Add OpenAI API key in .env
3. Run backend/app.py
